#ifndef SUBSCRIPTIONS_H
#define SUBSCRIPTIONS_H
enum class SubscriptionType{GEESE,ROLL,DISPLAY};
#endif
