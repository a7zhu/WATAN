#ifndef _RESOURCES_H_
#define _RESOURCES_H_
enum class Resources { TUTORIAL=0, STUDY, CAFFEINE, LAB, LECTURE, NETFLIX };
#endif
